plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.tvscan"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.tvscan"
        minSdk = 21; targetSdk = 34; versionCode = 1; versionName = "1.0"
        listOf("VT_API_KEY", "MB_API_KEY", "MD_API_KEY").forEach {
            buildConfigField("String", it, "\"${project.findProperty(it) ?: ""}\"")
        }
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
