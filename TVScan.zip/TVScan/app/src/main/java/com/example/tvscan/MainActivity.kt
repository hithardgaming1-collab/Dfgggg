package com.example.tvscan

import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var upload: CheckBox
    private lateinit var btns: List<Button>
    private val sb = StringBuilder()
    private val perm = android.Manifest.permission.READ_EXTERNAL_STORAGE
    private var pendingMode = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 48, 64, 48)
            setBackgroundColor(Color.parseColor("#101418"))
        }
        val on = Scanner.enabled()
        status = TextView(this).apply {
            textSize = 24f; setTextColor(Color.WHITE)
            text = if (on.isEmpty()) "No API keys set: local checks only" else "Sources: ${on.joinToString()}"
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        btns = listOf(
            btn("Check Downloads folder (all file types)") { scanFiles(1) },
            btn("Scan my installed apps") { start(true, false, 0) },
            btn("Scan installed apps + system apps (slow)") { start(true, true, 0) },
            btn("Scan all storage + USB (risky file types)") { scanFiles(2) }
        )
        upload = CheckBox(this).apply {
            text = "Upload unknown files to VirusTotal (they become visible to VT researchers)"
            textSize = 18f; setTextColor(Color.LTGRAY)
            if (BuildConfig.VT_API_KEY.isEmpty()) visibility = View.GONE
        }
        log = TextView(this).apply { textSize = 18f; setTextColor(Color.LTGRAY) }
        root.addView(status); btns.forEach { root.addView(it) }; root.addView(upload)
        root.addView(ScrollView(this).apply { isFocusable = false; addView(log) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        btns[0].requestFocus()
    }

    private fun scanFiles(mode: Int) {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            pendingMode = mode; requestPermissions(arrayOf(perm), 1)
        } else start(false, false, mode)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) start(false, false, pendingMode)
        else status.text = "Storage permission denied"
    }

    private fun start(apps: Boolean, system: Boolean, fileMode: Int) {
        btns.forEach { it.isEnabled = false }
        sb.setLength(0); log.text = ""
        val up = upload.isChecked
        Thread {
            var msg: String
            try {
                val r = Scanner.scan(this, apps, system, fileMode, up, { m -> runOnUiThread { status.text = m } }) { f ->
                    runOnUiThread { sb.append("[${f.verdict}] ${f.label}\n   ${f.detail}\n\n"); log.text = sb.toString() }
                }
                msg = "Done: ${r.first} scanned, ${r.second} flagged"
            } catch (e: Exception) { msg = "Scan failed: ${e.message}" }
            runOnUiThread { status.text = msg; btns.forEach { it.isEnabled = true }; btns[0].requestFocus() }
        }.start()
    }
}
