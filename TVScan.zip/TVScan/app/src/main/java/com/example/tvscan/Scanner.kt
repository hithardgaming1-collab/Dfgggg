package com.example.tvscan

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Environment
import android.provider.Settings
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

data class Finding(val label: String, val verdict: String, val detail: String)

class RateLimit : Exception("rate limit hit, skipped")

/** One cloud database. lookup() = detections (0 = seen and clean), or null if the hash is unknown to it. */
abstract class Source(val name: String, val key: String, private val gapMs: Long) {
    var dead = false
    private var last = 0L
    protected abstract fun call(hash: String): Int?
    fun pace() {
        val w = last + gapMs - System.currentTimeMillis()
        if (w > 0) Thread.sleep(w)
        last = System.currentTimeMillis()
    }
    fun lookup(hash: String): Int? {
        pace()
        return try { call(hash) }
        catch (e: RateLimit) { dead = true; throw e }
        finally { last = System.currentTimeMillis() }
    }
}

private fun http(url: String, headers: Map<String, String>, post: String? = null): Pair<Int, String> {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 10_000; c.readTimeout = 20_000
    headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
    if (post != null) { c.doOutput = true; c.outputStream.use { it.write(post.toByteArray()) } }
    val code = c.responseCode
    if (code == 429) throw RateLimit()
    val body = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
    return Pair(code, body)
}

/** Confirmed malware samples only: a hit means known-bad (99), a miss means nothing. */
class MalwareBazaar(k: String) : Source("MalwareBazaar", k, 300) {
    override fun call(hash: String): Int? {
        val (code, body) = http("https://mb-api.abuse.ch/api/v1/", mapOf("Auth-Key" to key), "query=get_info&hash=$hash")
        if (code != 200) throw RuntimeException("HTTP $code")
        return if (JSONObject(body).optString("query_status") == "ok") 99 else null
    }
}

class MetaDefender(k: String) : Source("MetaDefender", k, 6_500) { // free tier ~10 req/min
    override fun call(hash: String): Int? {
        val (code, body) = http("https://api.metadefender.com/v4/hash/$hash", mapOf("apikey" to key))
        if (code == 404) return null
        if (code != 200) throw RuntimeException("HTTP $code")
        return JSONObject(body).optJSONObject("scan_results")?.optInt("total_detected_avs", 0)
    }
}

class VirusTotal(k: String) : Source("VirusTotal", k, 15_500) { // free tier 4 req/min
    override fun call(hash: String): Int? {
        val (code, body) = http("https://www.virustotal.com/api/v3/files/$hash", mapOf("x-apikey" to key))
        if (code == 404) return null
        if (code != 200) throw RuntimeException("HTTP $code")
        return JSONObject(body).getJSONObject("data").getJSONObject("attributes")
            .getJSONObject("last_analysis_stats").getInt("malicious")
    }

    /** Uploads a file (max 32 MB) for a fresh scan by ~70 engines and waits for the verdict (up to ~4 min). */
    fun upload(f: File): Int {
        val b = "----tvscan${System.nanoTime()}"
        val head = "--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"${f.name.replace("\"", "_")}\"\r\nContent-Type: application/octet-stream\r\n\r\n".toByteArray()
        val tail = "\r\n--$b--\r\n".toByteArray()
        pace()
        val c = URL("https://www.virustotal.com/api/v3/files").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("x-apikey", key)
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
        c.setFixedLengthStreamingMode(head.size + f.length() + tail.size)
        c.outputStream.use { o -> o.write(head); f.inputStream().use { it.copyTo(o) }; o.write(tail) }
        if (c.responseCode == 429) { dead = true; throw RateLimit() }
        if (c.responseCode != 200) throw RuntimeException("upload HTTP ${c.responseCode}")
        val id = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getJSONObject("data").getString("id")
        repeat(16) {
            pace()
            val (code, body) = http("https://www.virustotal.com/api/v3/analyses/$id", mapOf("x-apikey" to key))
            if (code == 200) {
                val a = JSONObject(body).getJSONObject("data").getJSONObject("attributes")
                if (a.getString("status") == "completed") return a.getJSONObject("stats").getInt("malicious")
            }
        }
        throw RuntimeException("analysis still running, try again later")
    }
}

object Scanner {
    private val RISKY = setOf("REQUEST_INSTALL_PACKAGES", "SYSTEM_ALERT_WINDOW", "READ_SMS", "RECEIVE_SMS",
        "SEND_SMS", "READ_CONTACTS", "READ_CALL_LOG", "RECORD_AUDIO", "MANAGE_EXTERNAL_STORAGE")
    private val EXT = setOf("apk", "xapk", "apks", "dex", "jar", "so", "zip", "rar", "7z", "exe", "msi", "bat",
        "cmd", "sh", "js", "vbs", "ps1", "scr", "lnk", "iso", "pdf", "doc", "docx", "xls", "xlsx")
    private const val DAY = 86_400_000L

    private class Item(val label: String, val file: File, val quick: Boolean) { val flags = mutableListOf<String>() }
    private class Cloud(val bad: Int, val found: Boolean, val note: String)

    fun enabled(): List<String> = listOf("MalwareBazaar" to BuildConfig.MB_API_KEY,
        "MetaDefender" to BuildConfig.MD_API_KEY, "VirusTotal" to BuildConfig.VT_API_KEY)
        .filter { it.second.isNotEmpty() }.map { it.first }

    /**
     * fileMode: 0 = none, 1 = Downloads folder (every file type), 2 = all storage + USB (risky types).
     * Returns (scanned, flagged). Call from a background thread.
     */
    fun scan(ctx: Context, apps: Boolean, system: Boolean, fileMode: Int, upload: Boolean,
             progress: (String) -> Unit, onResult: (Finding) -> Unit): Pair<Int, Int> {
        val items = mutableListOf<Item>()
        if (apps) items += appItems(ctx, system)
        if (fileMode != 0) items += fileItems(ctx, fileMode)
        val sources = listOf(MalwareBazaar(BuildConfig.MB_API_KEY), MetaDefender(BuildConfig.MD_API_KEY),
            VirusTotal(BuildConfig.VT_API_KEY)).filter { it.key.isNotEmpty() }
        val cache = ctx.getSharedPreferences("hashes", Context.MODE_PRIVATE)
        var flagged = 0

        items.forEachIndexed { i, item ->
            progress("(${i + 1}/${items.size}) ${item.label}")
            val c = when {
                !item.file.canRead() -> Cloud(0, false, "unreadable")
                sources.isEmpty() -> Cloud(0, false, "no API keys set")
                else -> cloud(item.file, sources, cache, item.quick, upload, progress)
            }
            val verdict = when {
                c.bad >= 3 -> "MALWARE"
                c.bad >= 1 -> "SUSPICIOUS"
                item.flags.isNotEmpty() -> "CHECK"
                !c.found -> "UNKNOWN"
                else -> "OK"
            }
            val bad = verdict == "MALWARE" || verdict == "SUSPICIOUS" || verdict == "CHECK"
            if (bad) flagged++
            // App scans list only problems; file scans list every file so you see the evidence.
            if (bad || fileMode != 0) onResult(Finding(item.label, verdict, (item.flags + c.note).filter { it.isNotEmpty() }.joinToString("; ")))
        }
        return Pair(items.size, flagged)
    }

    /** Asks each source in turn. Stops early on a confirmed hit; in quick mode, on the first source that knows the file. */
    private fun cloud(file: File, sources: List<Source>, cache: SharedPreferences, quick: Boolean,
                      upload: Boolean, progress: (String) -> Unit): Cloud {
        val hash = sha256(file)
        cache.getString(hash, null)?.split("|", limit = 4)?.let {
            if (System.currentTimeMillis() - it[0].toLong() < 7 * DAY) return Cloud(it[1].toInt(), true, it[3])
        }
        var bad = 0; var found = false; var ok = true
        val notes = mutableListOf<String>()
        for (s in sources) {
            if (s.dead) continue
            try {
                val r = s.lookup(hash)
                notes += "${s.name}: " + when { r == null -> "not found"; r >= 99 -> "known malware sample"; else -> "$r detections" }
                if (r != null) { found = true; bad = maxOf(bad, r); if (r >= 3 || quick) break }
            } catch (e: Exception) { ok = false; notes += "${s.name}: ${e.message}" }
        }
        val vt = sources.filterIsInstance<VirusTotal>().firstOrNull()
        if (upload && ok && !found && vt != null && !vt.dead) {
            if (file.length() > 32_000_000L) notes += "too big to upload (32 MB max)"
            else try {
                progress("Uploading ${file.name} to VirusTotal, this can take a few minutes...")
                val r = vt.upload(file); found = true; bad = r; notes += "VirusTotal fresh scan: $r detections"
            } catch (e: Exception) { ok = false; notes += "upload: ${e.message}" }
        }
        val note = notes.joinToString(", ")
        if (ok && found) cache.edit().putString(hash, "${System.currentTimeMillis()}|$bad|1|$note").apply()
        return Cloud(bad, found, note)
    }

    private fun riskyPerms(p: PackageInfo) =
        (p.requestedPermissions ?: emptyArray()).map { it.substringAfterLast('.') }.filter { it in RISKY }

    private fun appItems(ctx: Context, system: Boolean): List<Item> {
        val pm = ctx.packageManager
        val a11y = Settings.Secure.getString(ctx.contentResolver, "enabled_accessibility_services") ?: ""
        fun sys(p: PackageInfo) = ((p.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM) != 0
        return pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
            .filter { it.packageName != ctx.packageName && it.applicationInfo != null && (system || !sys(it)) }
            .sortedBy { sys(it) } // user-installed first
            .map { p ->
                val ai = p.applicationInfo!!
                val s = sys(p)
                val item = Item("${ai.loadLabel(pm)} (${p.packageName})", File(ai.sourceDir), s)
                if (!s) {
                    @Suppress("DEPRECATION")
                    if (pm.getInstallerPackageName(p.packageName) == null) item.flags += "sideloaded"
                    val r = riskyPerms(p)
                    if (r.size >= 3) item.flags += "risky permissions: ${r.joinToString()}"
                    if (a11y.contains(p.packageName + "/")) item.flags += "accessibility service enabled"
                }
                item
            }
    }

    /** Android 9 lets an app with READ_EXTERNAL_STORAGE read internal storage, other apps' download folders and USB drives. */
    private fun fileItems(ctx: Context, mode: Int): List<Item> {
        val pm = ctx.packageManager
        @Suppress("DEPRECATION")
        val roots = if (mode == 1) listOf(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS))
        else listOf(Environment.getExternalStorageDirectory()) +
            (File("/storage").listFiles()?.filter { it.name != "self" && it.name != "emulated" } ?: emptyList())
        return roots.flatMap { r ->
            r.walkTopDown().onEnter { it.canRead() }
                .filter { it.isFile && it.length() in 1L..200_000_000L && (mode == 1 || it.extension.lowercase() in EXT) }
                .take(if (mode == 1) 200 else 500).toList()
        }.map { f ->
            // For an APK, also read its package name and permissions BEFORE you install it.
            val info = if (f.extension.equals("apk", true)) pm.getPackageArchiveInfo(f.path, PackageManager.GET_PERMISSIONS) else null
            val item = Item(f.path + (info?.let { " [${it.packageName}]" } ?: ""), f, true)
            info?.let { val r = riskyPerms(it); if (r.size >= 3) item.flags += "risky permissions: ${r.joinToString()}" }
            item
        }
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { s ->
            val b = ByteArray(65536)
            while (true) { val n = s.read(b); if (n < 0) break; md.update(b, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
